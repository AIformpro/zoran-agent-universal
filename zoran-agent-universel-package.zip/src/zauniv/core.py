class ZoranAgentUniversel:
    def __init__(self, backend="OpenAI"):
        self.backend = backend
    def run_mode(self, mode):
        return f"Mode {mode} exécuté sur backend {self.backend}"
