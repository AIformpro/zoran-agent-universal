from zauniv.core import ZoranAgentUniversel

agent = ZoranAgentUniversel()
print(agent.run_mode("mode_demo"))
