from zauniv.core import ZoranAgentUniversel

def test_run_mode():
    agent = ZoranAgentUniversel()
    assert "exécuté" in agent.run_mode("test")
